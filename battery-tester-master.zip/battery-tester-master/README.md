# battery-tester
An open source multi cell Li-Ion battery tester.
